"""Reference-only executor. No product imports; preserve raw native semantics."""
import json,pathlib,hashlib,platform,sys
import numpy as np
import talib
OUT=pathlib.Path(__file__).resolve().parent
talib.set_compatibility(0)
for name in talib.get_function_groups()['Overlap Studies']+talib.get_function_groups()['Momentum Indicators']+talib.get_function_groups()['Volatility Indicators']:
    try: talib.set_unstable_period(name,0)
    except KeyError: pass
results=[]
for case in json.loads((OUT/'expected-math.json').read_text()):
    c=case['component']; p=case['parameters']; d=case['data']; n=len(d['close']); out={k:np.full(n,np.nan) for k in case['expected']}; source=p.get('source','close')
    fs={'hl2':['high','low'],'hlc3':['high','low','close'],'ohlc4':['open','high','low','close']}.get(source,[source])
    if c in ('KELTNER_CHANNELS','STOCHASTIC'): fs=['high','low','close']
    if c=='DONCHIAN_CHANNELS': fs=['high','low']
    valid=np.array([all(d[f][i] is not None and np.isfinite(d[f][i]) for f in fs) for i in range(n)])
    errors=[]; i=0
    while i<n:
        if not valid[i]: i+=1; continue
        j=i+1
        while j<n and valid[j]: j+=1
        a={f:np.array(d[f][i:j],dtype=float) for f in d}; x=np.mean([a[f] for f in fs],axis=0) if c=='MACD' else a['close']
        try:
            if c.startswith('BOLLINGER'):
                u,m,l=talib.BBANDS(x,timeperiod=p['window'],nbdevup=p['deviations'],nbdevdn=p['deviations'],matype=0)
                if c=='BOLLINGER_BANDS': v={'lower':l,'middle':m,'upper':u}
                else:
                    with np.errstate(all='ignore'): v={'value':100*(u-l)/m if c=='BOLLINGER_BANDWIDTH' else (x-l)/(u-l)}
            elif c=='DONCHIAN_CHANNELS':
                l=talib.MIN(a['low'],timeperiod=p['window']); u=talib.MAX(a['high'],timeperiod=p['window']); v={'lower':l,'upper':u,'middle':(l+u)/2}
            elif c=='KELTNER_CHANNELS':
                m=(talib.EMA if p['basis_type']=='EMA' else talib.SMA)(x,timeperiod=p['window']); atr=talib.ATR(a['high'],a['low'],x,timeperiod=p['atr_length']); m[np.isnan(atr)]=np.nan
                v={'middle':m,'lower':m-p['multiplier']*atr,'upper':m+p['multiplier']*atr}
            elif c=='MACD':
                m,s,h=talib.MACD(x,fastperiod=p['fast_length'],slowperiod=p['slow_length'],signalperiod=p['signal_length']); v={'macd':m,'signal':s,'histogram':h}
            elif c=='PPO': v={'value':talib.PPO(x,fastperiod=p['fast_length'],slowperiod=p['slow_length'],matype=1 if p['moving_average_type']=='EMA' else 0)}
            elif c=='STOCHASTIC':
                k,dd=talib.STOCH(a['high'],a['low'],x,fastk_period=p['k_length'],slowk_period=p['k_smoothing'],slowk_matype=0,slowd_period=p['d_smoothing'],slowd_matype=0); v={'k':k,'d':dd}
            elif p['k_smoothing']==1:
                k,dd=talib.STOCHRSI(x,timeperiod=p['rsi_length'],fastk_period=p['stochastic_length'],fastd_period=p['d_smoothing'],fastd_matype=0); v={'k':k,'d':dd}
            else:
                r=talib.RSI(x,timeperiod=p['rsi_length']); k,dd=talib.STOCH(r,r,r,fastk_period=p['stochastic_length'],slowk_period=p['k_smoothing'],slowk_matype=0,slowd_period=p['d_smoothing'],slowd_matype=0); v={'k':k,'d':dd}
            for k,val in v.items(): out[k][i:j]=val
        except Exception as e: errors.append({'segment':[i,j],'error':str(e)})
        i=j
    results.append({'id':case['id'],'component':c,'parameters':p,'raw_expected':{k:[None if not np.isfinite(v) else float(v) for v in a] for k,a in out.items()},'errors':errors})
with (OUT/'expected-native.json').open('x') as f: json.dump(results,f,separators=(',',':')); f.write('\n')
with (OUT/'native-environment.json').open('x') as f: json.dump({'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'talib_wrapper':talib.__version__,'talib_core':str(talib.__ta_version__),'compatibility':talib.get_compatibility(),'unstable':{k:talib.get_unstable_period(k) for k in ['EMA','RSI','ATR']}},f,indent=2)
print('Raw native/composed-reference cases',len(results),'errors',sum(len(r['errors']) for r in results))
