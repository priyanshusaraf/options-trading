# Fresh corrected session-data assurance

## Verdict

**ASSURANCE REJECT**

The protected 31-decision wave does not satisfy the stopping condition. Exactly 17 candidates and 14 typed refusals are closed, but all eight prior-F01 candidates still omit `SESSION_OPEN_AT` and accept a second-slot session start.

## F01-FRESH — missing first-session history remains accepted

Affected components: `DISTANCE_FROM_SESSION_HIGH_LOW`, `PREVIOUS_SESSION_FIELDS`, `PREVIOUS_SESSION_OHLC`, `SESSION_HIGH`, `SESSION_LOW`, `SESSION_OPEN`, `SESSION_OPEN_HIGH_LOW`, `VWAP`.

The isolated historical reproduction reached the original fallback: without canonical session-open evidence, `_session_context` inferred the open as one timeframe before the first observed row. The current contracts still omit that evidence for the same eight candidates. Their suffix results therefore exclude the true first bar. Once an observed suffix reaches the declared close, `PREVIOUS_SESSION_FIELDS` and `PREVIOUS_SESSION_OHLC` can expose the incomplete aggregate as the preceding completed session.

Direct fresh evidence is in `focused-initial.xml`: 58 checks, 2 failures, both F01 consequences. The previous assurance compatibility run independently reproduced the same eight-name failure: 89 passed, 1 failed.

## Evidence accepted within the rejected wave

- Exact closure of all 31 decisions: 17 unpublished candidates and 14 non-executable typed refusals.
- Complete independent Decimal/specification arrays and validity masks for every candidate output and all five previous-session field variants.
- Overnight, holiday-gap, shortened, reversal, internal-gap, opening-range and explicit-anchor cases.
- Batch, prefix, stream, serialized restart and cold replay parity across every candidate.
- Real resolver, contract materializer, data-plan compiler/verifier and v2 runtime consumption for all candidates.
- Exact 125 legacy and 84 previously accepted v2 identities; 17 session candidate identities are recorded in `candidate-identities.json`.
- 56/56 checks passed after deselecting only the two direct F01 assertions.
- Four isolated source mutations were killed and original product/test/oracle bytes remained exact.
- Two actual 100,000-event workloads remained within declared compute, memory and state bounds; first-above counters refused.

## Identity disposition

The nine candidates outside F01 retain recorded unpublished identities. The eight affected candidates have no acceptable corrected identity closure because their protected source contracts still omit `SESSION_OPEN_AT`. A future correction must create and explain the required new source, binding and implementation addresses while preserving the 125 legacy and 84 accepted v2 identities.

## Required correction route and limits

Return F01-FRESH to a bounded product correction and then dispatch another fresh owner. This assurance made no product or existing-fixture edit and authorizes no registry publication, provider/calendar certification, frontend, schema, paper/live, order, money, deployment or V0 completion.
