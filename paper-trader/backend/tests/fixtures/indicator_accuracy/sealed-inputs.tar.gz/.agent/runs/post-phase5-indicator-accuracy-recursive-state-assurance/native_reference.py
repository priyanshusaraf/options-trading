import json,math,hashlib,platform,sys
from pathlib import Path
import talib,numpy as np
O=Path(__file__).parent
assert talib.__version__=='0.7.1'
talib.set_compatibility(0)
for k in ('ADX','ATR','EMA','KAMA','MINUS_DI','NATR','PLUS_DI','RSI'):talib.set_unstable_period(k,0)
rename={'ACCUMULATION_DISTRIBUTION':'AD','CHAIKIN_OSCILLATOR':'ADOSC','PARABOLIC_SAR':'SAR'}
results=[]
for c in json.loads((O/'expected-vectors.json').read_text()):
 n=c['name'];p=c['parameters'];f=rename.get(n,n)
 if not hasattr(talib,f) or c.get('breaks'):continue
 if any(not math.isfinite(v) for r in c['rows'] for v in r.values()):continue
 if any(r['high']<r['low'] or r['volume']<0 for r in c['rows']):continue
 if n=='KAMA' and (p['fast_length'],p['slow_length'])!=(2,30):continue
 if n=='PARABOLIC_SAR' and p['start']!=p['increment']:continue
 a={k:np.array([r[k] for r in c['rows']],dtype=float) for k in c['rows'][0]}
 args=[a[k] for k in ('high','low','close','volume')] if f in ('AD','ADOSC') else [a[k] for k in ('high','low','close')] if f in ('ADX','ATR','MINUS_DI','NATR','PLUS_DI') else [a[k] for k in ('high','low')] if f=='SAR' else [a[k] for k in ('close','volume')] if f=='OBV' else [a['close']]
 kw={'timeperiod':p['window']} if 'window' in p else {}
 if f=='ADOSC':kw=dict(fastperiod=p['fast_length'],slowperiod=p['slow_length'])
 if f=='SAR':kw=dict(acceleration=p['start'],maximum=p['maximum'])
 y=getattr(talib,f)(*args,**kw)
 results.append(dict(id=c['id'],values=[float(v) if math.isfinite(v) else None for v in y]))
(O/'native-vectors.json').write_text(json.dumps(results,separators=(',',':'))+'\n')
(O/'native-runtime.json').write_text(json.dumps(dict(python=sys.version,platform=platform.platform(),talib=talib.__version__,core=talib.__ta_version__.decode(),numpy=np.__version__,compatibility=talib.get_compatibility(),unstable={k:talib.get_unstable_period(k) for k in ('ADX','ATR','EMA','KAMA','MINUS_DI','NATR','PLUS_DI','RSI')}),indent=2)+'\n')
print('Native reference cases',len(results))
