"""Exact rational adjudication of short STOCH_RSI vectors.

The first sealed Decimal oracle develops cancellation residuals in exact constant
RSI windows. Preserve that original evidence; this independent Fraction model
settles whether such windows really have zero range. No product formula imports.
"""
from fractions import Fraction as F
import hashlib,json,math,pathlib,datetime
OUT=pathlib.Path(__file__).resolve().parent
def exact_block(values,p):
    n=len(values); w=p['rsi_length']; r=[None]*n; g=l=F(0)
    for i in range(1,n):
        delta=values[i]-values[i-1]; gain=max(delta,0); loss=max(-delta,0)
        if i<=w:
            g+=gain; l+=loss
            if i<w: continue
            g/=w; l/=w
        else: g=(g*(w-1)+gain)/w; l=(l*(w-1)+loss)/w
        r[i]=100*g/(g+l) if g+l else F(0)
    raw=[None]*n
    for i in range(w+p['stochastic_length']-1,n):
        win=r[i-p['stochastic_length']+1:i+1]; lo=min(win); hi=max(win)
        raw[i]=100*(r[i]-lo)/(hi-lo) if hi!=lo else F(0)
    def mean(a,k):
        out=[None]*n
        for i in range(k-1,n):
            win=a[i-k+1:i+1]
            if all(v is not None for v in win): out[i]=sum(win,F(0))/k
        return out
    k=mean(raw,p['k_smoothing']); d=mean(k,p['d_smoothing'])
    return {'k':[None if dd is None else float(kk) for kk,dd in zip(k,d)],'d':[None if v is None else float(v) for v in d]}
def calculate(case):
    data=case['data']['close']; out={k:[None]*len(data) for k in ('k','d')}; i=0
    while i<len(data):
        if data[i] is None or not math.isfinite(data[i]): i+=1; continue
        j=i+1
        while j<len(data) and data[j] is not None and math.isfinite(data[j]): j+=1
        block=exact_block([F(v) for v in data[i:j]],case['parameters'])
        for k in out: out[k][i:j]=block[k]
        i=j
    return out
if __name__=='__main__':
    results={}
    for case in json.loads((OUT/'expected-math.json').read_text()):
        if case['component']=='STOCH_RSI' and '-maximum-' not in case['id']: results[case['id']]=calculate(case)
    target=OUT/'expected-rational-stochrsi.json'
    target.open('x').write(json.dumps(results,separators=(',',':'))+'\n')
    seal={'schema':'independent-rational-adjudication/1','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Exact zero-range adjudication; initial Decimal90 expectations remain sealed, no product results copied.','cases':len(results),'artifacts_sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [target,pathlib.Path(__file__)]}}
    (OUT/'rational-seal.json').open('x').write(json.dumps(seal,indent=2)+'\n')
    print('Exact rational supplementary cases',len(results))
