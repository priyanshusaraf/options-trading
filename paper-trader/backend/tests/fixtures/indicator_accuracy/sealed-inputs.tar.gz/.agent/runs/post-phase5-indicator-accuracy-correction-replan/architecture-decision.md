# Indicator accuracy correction architecture

## Verdict

**KEEP + HARDEN** the one registry, resolver, numeric envelope, data-requirement
compiler and research lineage. **REPLACE through new semantic versions** the
rejected or incompletely specified analytical contracts. **REFUSE** outputs whose
canonical data binding or numerical convention is not accepted. This is an
architecture decision, not an accuracy PASS for any new implementation.

The original audit remains 25 narrowly verified / 60 rejected / 40 unverified.
All 125 candidates remain unpublished in this replan. The matrix distinguishes
those historical observations from the proposed decisions and future evidence.

## Immutable version 1

`app/ir/first_party/analytical.py` is a permanently protected legacy defining module
for this programme. Its registrations use `DependencyBoundary("defining_module",
(math, np, pd))`; an additive edit would still alter all 125 implementation hashes.
The exact current descriptors, contracts, declarations and implementation addresses
are in `current-catalogue.json`. Do not move, rename, wrap or edit the old functions
as a shortcut. Do not mutate their synthetic provenance references in place.

Candidate component version 2 preserves each stable component ID. Numerically
matched formulas may be kept, but their repaired parameters, named ports, validity,
provenance or reset contracts still require a new version. New modules are disjoint
contributors composed through `app.ir.library`; they are not a second registry.
Do not change a published v2 helper after a wave is accepted. Any later semantic or
transitive implementation change requires another explicit version and new evidence.

Registry snapshots are distinct from component identities. Adding v2 changes the
current registry snapshot even when v1 component bytes stay fixed. Preserve old
snapshot payloads and addresses as historical facts. Never rewrite an old result,
graph, admission, cache key or snapshot to match the enlarged current registry.
An unavailable historical implementation/lock must cause an explicit reproduction
refusal, not substitution of the current environment under an old identity.

## Parameter-dependent contracts: bounded extension, no expression language

The current `first-party-node-contract/1` requires an integer `warmup_history` and a
fixed `required_resolution`; the data declaration permits only literals or direct
parameter references. It cannot faithfully express all MACD/Stochastic warmups,
conditional source fields and canonical input timeframes. The old uniform 14/60
contract and invented resource constants must not be relabelled accurate.

The contract-foundation capsule owns one versioned successor at the existing
canonical validator/resolver boundary. It must preserve the entire `/1` branch and
its canonical bytes. The successor is `first-party-node-contract/2`, with the same
22 semantic obligations and an explicit closed binding record, not executable
user expressions. Only audited, registry-owned binding rule identifiers are
accepted. Each rule's implementation identity belongs in the registration/snapshot
closure. No eval, arbitrary formula DSL, plugin discovery or second compiler.

For each v2 node, the existing resolver must bind its canonical parameters and input
instrument/timeframe/session identity to a concrete contract and concrete existing
DataRequirementPlan rows. The bound receipt includes source contract address,
rule/implementation address, canonical parameters, input binding and resulting
contract/declaration addresses. Recompute and compare this binding before planning,
job claim/reclaim and evaluation; do not accept client-supplied history/readiness.
Both template and bound facts must survive cache/research serialization. The same
compiler verifies the bound closure, using version dispatch rather than a parallel
research path. Any persistence migration requirement stops foundation for a new
explicit schema owner gate; JSON contract evolution alone does not authorize SQL.

The exact parameter domains and first-valid rules are in the matrix. Numeric window
parameters are bounded, generally 2..4096; lags/smoothing explicitly allow 1 where
specified. This is a v2 resource/safety choice, not a reinterpretation of v1's
1..100000 parameter domain. Inputs expose explicit primary/peer roles, selected
price fields and canonical timeframe; no silently fixed 60-second declaration.
The foundation must test forged lower warmup, changed source, changed role,
changed timeframe, reordered parameters and wrong rule/contract addresses.

The exact successor shapes and binding obligations are frozen in
`binding-contract-spec.json`. Candidate descriptors may declare their intended
research-only mode, but publication is withheld until proof; do not flip a flag in
a frozen descriptor on acceptance.

Resource values cannot be copied from the old generic 50µs/4096-byte descriptor.
Each implementation wave supplies measured, conservative bounds over its declared
parameter domain; assurance rejects missing or understated bounds. Research
eligibility stays false until those bounds and the semantic proof pass. Paper and
live eligibility remain false for the v2 accuracy release.

## Validity, sessions and outputs

Required inputs/authority missing at call entry cause a typed refusal. Per-bar
missing/invalid data produce the existing numeric envelope's invalid/unknown state,
not a plausible value or boolean False. No forward fill, row compression, fallback
to close, hidden peer=open, or arbitrary zero is permitted. A gap resets contiguous
warmup and recursive state; formulas with an explicitly defined constant/zero case
use that exact case only on otherwise valid data. Infinities never become signals.

Every output is a named typed port. A DataFrame beneath a scalar `value` port is
not a substitute. Multi-output validity is pinned by the named reference: common
lookback masks where TA-Lib requires them; explicit independent masks otherwise.
All outputs preserve availability/decision time. Appending a suffix must not change
an earlier output or mask. A chart displacement never makes a future value known
at a past decision time.

Session operations consume the existing canonical market-truth/calendar authority,
not `index.normalize()`, civil midnight or a new calendar model. The session/data
wave can prove calculations against independently specified synthetic canonical
sessions; it does not certify a provider's actual exchange calendar. V0-D must prove
the data-only binding before those capabilities become available on real datasets.
If the canonical context cannot provide the required receipt, refuse the node.

## Explicit convention decisions

- Level OLS, return beta and time-index regression are separate definitions. BETA
  uses primary returns on peer returns; hedge ratio uses levels; time-index slope
  and intercept do not consume peer. Alpha is a per-bar return intercept, not CAPM.
- ROC/PERCENT_RETURN retain explicitly labelled decimal-return units. Percentile
  is a value quantile; percentile rank, ordinal rolling rank and volatility range
  rank are different operations with stated tie/zero rules.
- MACD, Stochastic, Stochastic RSI and channels receive complete named outputs and
  explicit parameters. KAMA and SAR parameter extensions have independent scalar
  oracle obligations; default compatible settings also match pinned TA-Lib.
- GARMAN_KLASS remains unavailable until the intended original estimator equation
  is inspected. An opening-jump benchmark from another paper must not substitute
  for the original simplified variant. Yang–Zhang uses sample variances and its
  window-dependent equation-10 weight. Every volatility output has explicit
  `periods_per_year`, default 1; neither 252 nor 365 is inferred.
- SUPERTREND and ICHIMOKU_COMPONENTS remain unavailable. Their required parameter
  and port surfaces are recorded, but no unverified seed, state machine or
  displacement convention is passed off as a primary-source match. Their dedicated
  deferred-source replan requires a new owner gate before enabling them.

## Refusals and release scope

Seventeen records are explicitly unavailable: fourteen quote/trade/OI/book/metadata/
clock/resampling bindings plus Supertrend, Ichimoku and Garman–Klass. This is a concrete refusal
contract, not an omitted component. No v2 numeric version or placeholder executable
stub is published for these records. A later accepted numerical definition can
therefore publish v2 without reinterpreting a previously published v2 refusal.
Every attempt to select/resolve an unavailable candidate must get a stable server
reason at the V0 authoring/admission boundary; no caller boolean grants capability.

The immutable v1 registry remains available only under its existing legacy rules.
The future V0 verified catalogue and new V0 research admission must exclude
unaccepted v1 analytical dependencies. Historical results remain viewable as
historical evidence with their rejected/unverified status, never automatically
promoted. Do not disable or mutate an existing standard-profile execution path,
live authority, or risk-reducing exit under this accuracy programme.

## Source and oracle independence

`source-authority.json` binds each record to local source hashes, immutable upstream
commits or captured primary documents, explicit variants and the future oracle
owner. TA-Lib core and wrapper are separately pinned at release v0.7.1. Neither is
adopted into product dependencies. Mathematical conventions authored here are
labelled Strategy OS specifications, not external vendor-parity evidence.

The predecessor comparison ran with pandas 2.3.2; the current backend lock/export
uses pandas 3.0.5 and numpy 2.5.2. Do not promote old numbers into a current-runtime
claim. Each assurance capsule must run against the locked product environment and
record both reference and product dependency/compiler identities. The predecessor
report did not pin its native TA-Lib build identity; new oracle evidence must.

Separate assurance owners must author/reference vectors without importing product
math, this specification generator's formula code, or implementation helper
functions. The source tables are specifications, not executable expected-value
oracles. Tests must compare every valid bar and the entire validity mask, including
warmup, flat/zero cases, impulses, reversals, gaps, NaN/infinity, irregular sessions,
parameter bounds, prefix invariance, batch/stream parity and state restart.
Expected values cannot be regenerated from the implementation being tested.

TradingView libraries, hosted chart probes, export APIs, credentials, scraping and
unofficial access are excluded. No TradingView output is required for this plan.
A separate owner/legal/access decision is required before any later private-library
use; it can only be secondary evidence, not sole source authority.

## Sequencing and stopping rule

Contract foundation → independent contract assurance → core math → its assurance →
recursive state → its assurance → multi-output → its assurance → session/data →
its assurance → remaining oracles → its assurance → registry/lineage integration →
independent full-universe assurance → one final Sol-high accuracy review.

Shared registry/runtime/cache/admission files belong only to foundation or final
integration, serially; numerical wave modules and their tests have disjoint paths.
The implementation programme is paused at the contract-foundation owner gate.
The verified V0 catalogue depends on the final dual-PASS accuracy review, not on
this replan's documentation verdict. No implementation starts in this capsule.
