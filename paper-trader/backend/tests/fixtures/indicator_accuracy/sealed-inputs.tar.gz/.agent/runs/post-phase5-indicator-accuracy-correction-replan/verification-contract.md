# Independent numerical verification contract

## Thresholds

Preserve the accepted audit's strict thresholds. They apply at every declared-valid
bar/output, not just the last value or overlapping finite samples.

| Class | Requirement |
|---|---|
| EXACT | Bitwise equality or absolute error <= 1e-12 for exact transforms; boolean/direction/event values and validity masks must be exact |
| NONRECURSIVE | Absolute error <= 1e-10 AND relative error <= 1e-9 |
| RECURSIVE | Exact seed/warmup, then absolute error <= 1e-10 AND relative error <= 1e-8 |
| REFUSAL_ONLY | Exact stable refusal/no numeric result; cannot be included in a numerical-pass total |

For a nonzero expected value, verify the relative inequality against its actual
magnitude. At exactly zero the relative error is undefined: require absolute error
<= 1e-12. Do not use the additive `atol + rtol*abs(expected)` acceptance of a generic
allclose as a substitute for the stated conjunction. Preserve maximum absolute and
relative errors and the failing bar/port/parameter identity in receipts. A threshold
change requires a new explicit source/accuracy decision, never a test-only relaxation.

## Complete-array comparators

Compare the entire output identity, order/index and validity mask before comparing
numbers. Unknown/NaN, boolean False and finite zero are different states. No overlap-
only mask can hide a missing seed, shifted series, missing session reset or output.
Compare every named output, parameter domain/default, declared input role/field,
first-valid index and source/dependency identity. Test that removing or swapping a
member makes the consumer fail. Never infer coverage from 125 rows or a test count.

The product and oracle must be separate implementations. No product evaluator,
helper, generated output or copied formula function may supply expected values.
Use pinned official reference settings plus independently authored scalar/decimal,
recurrence and canonical-session fixtures. Published fixtures remain immutable;
new product output cannot overwrite them. Record the exact native/wrapper/build
and locked product environment. The old pandas 2.3.2 audit is not pandas 3.0.5 proof.

## Adversarial fixtures

Each applicable component/port needs defaults, nondefault parameters, minimum,
maximum and first-above-maximum values; bool-as-int and extra/missing parameters;
flat/zero and repeated/tied prices; monotone ramps; impulses and sudden gaps;
reversals; noisy independent primary/peer paths; NaN/infinity and absent fields;
wrong role/alignment/freshness; complete and incomplete warmup; and identity changes.

Session tests use canonical overnight, holiday-gap and shortened-session fixtures,
not only midnight-normalized business days. Test missing first/session bars, opening
range completion, previous-session availability and explicit anchors. A future
suffix must not change prior values/masks. For recursive/rolling state, checkpoint
and restore before/at/after warmup, missing gaps, session boundaries and reversals;
batch, streaming, restored and cold-replay results must agree under the same receipt.

For the 17 refusal records, attempt the forbidden path with missing and plausible
input values and with a caller-supplied capability flag. Each must refuse/no-value
at the advertised V0 boundary. A synthetic provider fixture cannot grant real data
or execution authority. No TradingView/private-library shortcut is permitted.

## Operational evidence

Every wave must measure conservative compute/history/memory/state demand across its
allowed parameter domain and prove the first-above-bound refusal. Do not copy the
old generic 50µs/4096-byte claims. Integration must exercise actual resolution,
resource acceptance, artifact serialization, enqueue/claim/reclaim, cache hit/miss,
public computation, result load and admission consumers under wrong/stale identities.
No schema counter or helper-only hash test replaces a consumer mutation.

One independent complete-universe assurance follows integration, then one final
SPEC/QUALITY review on a sealed package. A numerical wave's PASS does not authorize
registry publication, frontend exposure, provider access, live mode or deployment.
