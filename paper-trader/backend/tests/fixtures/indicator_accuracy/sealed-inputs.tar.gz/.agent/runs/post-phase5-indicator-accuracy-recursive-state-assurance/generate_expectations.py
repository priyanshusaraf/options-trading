import json,sys,hashlib,importlib.util,platform
from pathlib import Path
R=Path(__file__).resolve().parents[3]; O=Path(__file__).parent
p=R/'paper-trader/backend/research_tests/test_indicator_accuracy_recursive_state_oracle.py'
spec=importlib.util.spec_from_file_location('independent_oracle',p); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.test_manual_seeds_and_cumulative_semantics()
rows=[]
for c in m.cases():
 c['expected']=m.expected(c['name'],c['rows'],c['parameters'],c.get('breaks',()))
 rows.append(c)
(O/'expected-vectors.json').write_text(json.dumps(rows,allow_nan=True,separators=(',',':'))+'\n')
traces={}
for n in m.NAMES:
 p=m.parameters(n,'minimum'); t=[]; m.segment(n,m.fixture(size=20),p,t); traces[n]={'parameters':p,'trace':t}
(O/'intermediate-seeds.json').write_text(json.dumps(traces,indent=2)+'\n')
print('Independent cases',len(rows),'complete output bars',sum(len(c['expected']) for c in rows))
