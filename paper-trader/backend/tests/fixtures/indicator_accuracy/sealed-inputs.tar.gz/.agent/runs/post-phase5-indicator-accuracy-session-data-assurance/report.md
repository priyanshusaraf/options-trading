# Session data independent assurance

## Verdict

**ASSURANCE REJECT**

The frozen implementation does not satisfy the complete-session-prefix contract. Eight of the 17 candidate components accept data beginning after the canonical first session bar and produce valid values from that suffix.

## F01 — missing first-session history is silently accepted

Affected components:

- `DISTANCE_FROM_SESSION_HIGH_LOW`
- `PREVIOUS_SESSION_FIELDS`
- `PREVIOUS_SESSION_OHLC`
- `SESSION_HIGH`
- `SESSION_LOW`
- `SESSION_OPEN`
- `SESSION_OPEN_HIGH_LOW`
- `VWAP`

These contracts omit `SESSION_OPEN_AT`. When the first observed row belongs to a session the state has not seen, `_session_context` infers an open one timeframe before that row. The implementation therefore cannot distinguish a true first slot from a mid-session suffix.

The direct guard failed with all eight names in `.agent/runs/post-phase5-indicator-accuracy-session-data-assurance/focused-rejection.xml`. This is not a test-harness failure. The independent Decimal oracle passed, every complete-array comparison passed, internal gaps were refused, and the remaining assurance plus implementation-owner suite passed 89/89.

The wrong-number effect reaches later state. Session open/high/low, distances and VWAP omit the missing first bar. If the suffix reaches the declared session close, the previous-session nodes can expose the incomplete aggregate as a completed preceding session.

## Evidence accepted within the rejected wave

- Exact 31-decision closure: 17 candidates and 14 refusal facts with no executable placeholders.
- Complete Decimal-derived arrays and validity masks for overnight, shortened and holiday-separated canonical sessions.
- Real resolver, materializer, data-plan compiler/verifier and v2 runtime execution for every candidate.
- Five previous-session field variants, anchor rules, parameter minima/maxima/first-above refusals, internal gaps, batch/stream/restart, and wrong binding-role/session/derived-local rejection.
- 125 legacy identities and 84 previously accepted v2 identities remained exact.
- Two isolated behavior/eligibility mutations were killed.
- Independent 100,000-event resource measurements remained inside the declared conservative bounds.
- Product, owner test, shared grammar, Q01, Q03 and accepted context-control seals remained frozen.

## Required correction route

Return F01 to a bounded product correction. Each affected candidate needs explicit canonical session-open or equivalent prefix-start evidence that lets the first observed bar be checked against the true first completed slot. Because that changes source/binding/implementation identity for affected v2 candidates, record the new addresses and preserve all 125 legacy plus 84 previously accepted identities. Then dispatch a fresh independent assurance owner.

No registry publication, frontend/provider access, live authority or deployment follows from any passing evidence in this rejected wave.
