"""Run only before implementation inspection. Refuses to replace existing vectors."""
import hashlib, importlib.util, json, math, pathlib, random
OUT=pathlib.Path(__file__).resolve().parent; ROOT=OUT.parents[2]
p=ROOT/'paper-trader/backend/research_tests/test_indicator_accuracy_multi_output_oracle.py'
spec=importlib.util.spec_from_file_location('independent_oracle',p); o=importlib.util.module_from_spec(spec); spec.loader.exec_module(o)
def data(kind,n):
    rng=random.Random(91027); c=[]
    for i in range(n):
        v=100+7*math.sin(i*.73)+rng.uniform(-3,3)+i*.07
        if kind=='ramp': v=10+i*.25
        if kind=='reversal': v=20+min(i,n-i)*.37
        if kind=='impulse': v=10+(45 if i==n//2 else 0)
        if kind=='flat': v=17
        if kind=='zero': v=0
        if kind=='near_flat': v=1+((i%7)-3)*1e-10
        if kind=='large_level': v=1e12+((i*17)%31)*.125
        if kind=='extreme': v=(1+(i%7)*.01)*1e150
        c.append(float(v))
    spread=0 if kind in ('flat','zero') else 1e-11 if kind=='near_flat' else 1e148 if kind=='extreme' else .4
    d={'close':c,'open':[v-spread/2 for v in c],'high':[v+spread for v in c],'low':[v-spread for v in c],'volume':[1000.+i for i in range(n)]}
    if kind=='missing':
        for f in ('open','high','low','close'):
            for i,v in [(0,None),(47,None),(93,float('inf')),(139,float('-inf'))]:
                if i<n: d[f][i]=v
    return d
cases=[]
for c,p in o.DEFAULTS.items():
    variants={'default':p,'minimum':{k:(1 if 'smoothing' in k or k=='signal_length' else 2) if isinstance(v,int) else v for k,v in p.items()},'small':{k:(3 if 'smoothing' in k or k=='signal_length' else 5) if isinstance(v,int) else v for k,v in p.items()},'maximum':{k:(20 if k in ('deviations','multiplier') else 4096) if isinstance(v,int) else v for k,v in p.items()}}
    for name,v in variants.items():
        if c in ('MACD','PPO') and name in ('minimum','small'): v['slow_length']=v['fast_length']+2
        if 'deviations' in v and name=='minimum': v['deviations']=1e-6
        if 'multiplier' in v and name=='minimum': v['multiplier']=1e-6
        kinds=['noisy','flat','zero','missing','ramp','impulse','reversal','near_flat','large_level','extreme'] if name=='default' else ['noisy','flat']
        for kind in kinds:
            n=max(192,o.first_valid(c,v)+12); d=data(kind,n)
            cases.append({'id':f'{c}-{name}-{kind}','component':c,'parameters':v,'data':d,'expected':o.oracle(c,v,d),'first_valid':o.first_valid(c,v),'threshold':'NONRECURSIVE' if c.startswith('BOLLINGER') or c in ('DONCHIAN_CHANNELS','STOCHASTIC') else 'RECURSIVE'})
    if c=='MACD':
        for s in ('open','high','low','hl2','hlc3','ohlc4'):
            v=p|{'source':s}; d=data('noisy',192); cases.append({'id':f'{c}-source-{s}','component':c,'parameters':v,'data':d,'expected':o.oracle(c,v,d),'first_valid':o.first_valid(c,v),'threshold':'RECURSIVE'})
    if c in ('PPO','KELTNER_CHANNELS'):
        v=p|{('moving_average_type' if c=='PPO' else 'basis_type'):'SMA'}; d=data('noisy',192)
        cases.append({'id':f'{c}-SMA','component':c,'parameters':v,'data':d,'expected':o.oracle(c,v,d),'first_valid':o.first_valid(c,v),'threshold':'RECURSIVE'})
    if c=='STOCH_RSI':
        v=p|{'k_smoothing':1}; d=data('noisy',192); cases.append({'id':f'{c}-native','component':c,'parameters':v,'data':d,'expected':o.oracle(c,v,d),'first_valid':o.first_valid(c,v),'threshold':'RECURSIVE'})
dest=OUT/'expected-math.json'
with dest.open('x') as f: json.dump(cases,f,separators=(',',':')); f.write('\n')
print('Fresh independently authored mathematical vectors:',len(cases),'components',len(o.PORTS),'ports',sum(map(len,o.PORTS.values())))
