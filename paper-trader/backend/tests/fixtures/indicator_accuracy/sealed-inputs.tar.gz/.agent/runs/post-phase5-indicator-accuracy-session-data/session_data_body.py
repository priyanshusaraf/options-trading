
ALL_NAMES = tuple(sorted(SPECS))
NAMES = tuple(name for name in ALL_NAMES if SPECS[name]["decision"] == "REPLACE_V2")
REFUSED_NAMES = tuple(name for name in ALL_NAMES if SPECS[name]["decision"] == "REFUSE")
NUMERIC_FIELDS = frozenset({"open", "high", "low", "close", "volume"})
SESSION_PREFIX_NAMES = frozenset({
    "BARS_SINCE_SESSION_OPEN", "DISTANCE_FROM_SESSION_HIGH_LOW", "OPENING_RANGE",
    "PREVIOUS_SESSION_FIELDS", "PREVIOUS_SESSION_OHLC", "SESSION_HIGH", "SESSION_LOW",
    "SESSION_OPEN", "SESSION_OPEN_HIGH_LOW", "VWAP",
})
SESSION_NAMES = SESSION_PREFIX_NAMES | {"TIME_TO_SESSION_CLOSE"}


def refusal_for(name):
    if name not in REFUSED_NAMES:
        raise node_contracts.NodeContractRefusal("SESSION_DATA_REFUSAL_UNKNOWN")
    return node_contracts._freeze({
        "schema": "analytical-unavailable-component/1",
        "component_id": "analytical." + name.lower(),
        "semantic_version": 2,
        "decision": "REFUSE",
        "code": SPECS[name]["refusal"]["code"],
        "release_owner": SPECS[name]["refusal"]["release_owner"],
        "future_requirement": SPECS[name]["refusal"]["future_requirement"],
        "source_addresses": SPECS[name]["source_addresses"],
        "executable": False,
    })


REFUSALS = node_contracts._freeze({name: refusal_for(name) for name in REFUSED_NAMES})


def component_key(name):
    if name in REFUSED_NAMES:
        raise node_contracts.NodeContractRefusal(SPECS[name]["refusal"]["code"])
    if name not in NAMES:
        raise node_contracts.NodeContractRefusal("SESSION_DATA_COMPONENT_UNAVAILABLE")
    return ("analytical." + name.lower(), 2)


def _canonical_timestamp(value, *, parameter=False):
    if parameter and not isinstance(value, str):
        raise node_contracts.NodeContractRefusal("SESSION_DATA_TIMESTAMP_PARAMETER")
    try:
        timestamp = pd.Timestamp(value)
        if pd.isna(timestamp) or timestamp.tzinfo is None:
            raise ValueError("timezone required")
        timestamp = timestamp.tz_convert("UTC")
        if parameter and timestamp.isoformat() != value:
            raise ValueError("canonical +00:00 form required")
        return timestamp
    except (TypeError, ValueError, OverflowError) as exc:
        raise node_contracts.NodeContractRefusal(
            "SESSION_DATA_TIMESTAMP_PARAMETER" if parameter else "SESSION_DATA_CANONICAL_TIME_REQUIRED"
        ) from exc


def parameters_for(name, parameters=None):
    component_key(name)
    supplied = {} if parameters is None else parameters
    specs = SPECS[name]["parameters"]
    if not isinstance(supplied, abc.Mapping) or set(supplied) - set(specs):
        raise node_contracts.NodeContractRefusal("SESSION_DATA_PARAMETERS_UNKNOWN")
    result = {}
    for key, spec in specs.items():
        if key not in supplied and spec.get("required") and spec.get("default") is None:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_PARAMETER_REQUIRED")
        value = supplied.get(key, spec.get("default"))
        if spec["type"] == "utc_timestamp":
            value = _canonical_timestamp(value, parameter=True).isoformat()
        elif spec["type"] == "enum":
            if type(value) is not str or value not in spec["values"]:
                raise node_contracts.NodeContractRefusal("SESSION_DATA_PARAMETER_ENUM")
        elif spec["type"] == "exact_integer":
            if type(value) is not int or not spec["minimum"] <= value <= spec["maximum"]:
                raise node_contracts.NodeContractRefusal("SESSION_DATA_PARAMETER_DOMAIN")
        else:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_PARAMETER_TYPE")
        result[key] = value
    return node_contracts._freeze(result)


def _declared_fields_by_port(name):
    numeric = tuple(sorted(field.upper() for field in SPECS[name]["inputs"] if field in NUMERIC_FIELDS))
    context = tuple(sorted(field.upper() for field in SPECS[name]["inputs"] if field not in NUMERIC_FIELDS))
    result = {}
    if numeric:
        result["frame"] = numeric
    if context:
        result["session"] = context
    return node_contracts._freeze(result)


def fields_by_port(name, parameters=None):
    parameters_for(name, parameters)
    return _declared_fields_by_port(name)


def first_valid_index(name, parameters=None):
    parameters_for(name, parameters)
    return 0


def _port(port_id, direction):
    result = {
        "port_id": port_id,
        "direction": direction,
        "semantic_flow": "value",
        "semantic_role": "market_frame" if direction == "input" else "analytical_value",
        "type_ref": {"type_id": "analytical.market_frame" if direction == "input" else "analytical.float64", "type_version": 2},
        "shape": "series",
    }
    if direction == "input":
        result["connections"] = {"cardinality": "single", "min": 1, "max": 1, "assembly": "single"}
    return result


def descriptor(name):
    parameters = {}
    for key, spec in SPECS[name]["parameters"].items():
        if spec["type"] == "utc_timestamp":
            parameters[key] = {"type": "str", "required": True, "default": None, "enum": None,
                               "domain": {"max_length": 40}, "units": "utc_timestamp", "serialization": "canonical-json"}
        elif spec["type"] == "enum":
            parameters[key] = {"type": "str", "required": False, "default": spec["default"],
                               "enum": list(spec["values"]), "domain": {"max_length": max(map(len, spec["values"]))},
                               "units": "choice", "serialization": "canonical-json"}
        else:
            parameters[key] = {"type": "int", "required": False, "default": spec["default"], "enum": None,
                               "domain": {"minimum": spec["minimum"], "maximum": spec["maximum"]},
                               "units": "minutes", "serialization": "canonical-json"}
    family = "market_data" if name in {"OPEN", "HIGH", "LOW", "CLOSE", "OHLCV"} else "indicator"
    return node_contracts._freeze({
        "component_id": component_key(name)[0], "component_version": 2,
        "domain_family": family, "structural_role": "transform", "parameters": parameters,
        "ports": [_port(port, "input") for port in sorted(_declared_fields_by_port(name))]
                 + [_port(port, "output") for port in sorted(SPECS[name]["outputs"])],
    })


def _binding_rule(name):
    parameter_specs = tuple((key, spec["type"], bool(spec.get("required", False)), spec.get("default"),
                             spec.get("minimum"), spec.get("maximum"), tuple(spec.get("values", ())))
                            for key, spec in sorted(SPECS[name]["parameters"].items()))
    port_fields = tuple((port, tuple(fields)) for port, fields in _declared_fields_by_port(name).items())
    outputs = tuple(sorted(SPECS[name]["outputs"]))
    builder = contracts.binding_result

    def bind(parameters, inputs, _spec=(name, parameter_specs, port_fields, outputs, builder)):
        name, parameter_specs, port_fields, outputs, builder = _spec
        if set(parameters) != {row[0] for row in parameter_specs}:
            raise ValueError("exact canonical parameters required")
        for key, kind, required, default, minimum, maximum, values in parameter_specs:
            value = parameters[key]
            if kind == "utc_timestamp":
                if (not isinstance(value, str) or not 20 <= len(value) <= 40
                        or not value.endswith("+00:00") or value.count("T") != 1):
                    raise ValueError("timestamp string required")
            elif kind == "enum":
                if type(value) is not str or value not in values:
                    raise ValueError("declared enum required")
            elif type(value) is not int or not minimum <= value <= maximum:
                raise ValueError("bounded exact integer required")
        primary_port = "frame" if any(port == "frame" for port, _ in port_fields) else "session"
        for port, fields in port_fields:
            fact = inputs["ports"][port]["binding"]
            expected_role = "primary" if port == primary_port else port
            if fact["instrument"]["role"] != expected_role:
                raise ValueError("input role differs")
            if port == "session" and (fact["session"] != "INSTRUMENT_CALENDAR" or fact["derived_local"] is not True):
                raise ValueError("canonical derived session context required")
        if name == "OPENING_RANGE":
            seconds = parameters["range_minutes"] * 60
            if seconds % inputs["ports"][primary_port]["binding"]["timeframe"]:
                raise ValueError("opening range must be whole bound bar slots")
        return builder(inputs, fields_by_port=dict(port_fields), warmup_history=0,
                       output_warmup={port: 0 for port in outputs})
    return bind


def source_contract(name):
    key = component_key(name)
    rule = {"rule_id": key[0] + ".binding", "rule_version": 1}
    session = name in SESSION_NAMES
    port_fields = _declared_fields_by_port(name)
    primary_port = "frame" if "frame" in port_fields else "session"
    required = []
    for port, fields in port_fields.items():
        role = "primary" if port == primary_port else port
        required.extend(field.lower() if role == "primary" else role + "." + field.lower() for field in fields)
    reset_reasons = ["DATA_GAP", "EXPLICIT", "IDENTITY_CHANGE"] + (["SESSION"] if session else [])
    profile = {
        "compute_microseconds_per_event": 250000,
        "memory_bytes_upper_bound": 33554432,
        "history_bytes_upper_bound": 2097152,
        "state_bytes_upper_bound": 4194304,
        "storage_bytes_per_day_upper_bound": 0,
        "subscription_count_upper_bound": 1,
        "fanout_upper_bound": 1,
    }
    return node_contracts._freeze({
        "schema": "first-party-node-contract/2", "stable_node_id": key[0], "semantic_version": 2,
        "visible_family": "TYPE_4" if name in {"OPEN", "HIGH", "LOW", "CLOSE", "OHLCV"} else "TYPE_2",
        "input_types": {port: "analytical.market_frame/series" for port in sorted(port_fields)},
        "output_types": {port: "analytical.float64/series" for port in SPECS[name]["outputs"]},
        "required_market_fields": sorted(required),
        "required_resolution": {"source": "canonical_input_binding", "port": primary_port,
                                "alignment": "SESSION" if session else "BAR_CLOSE"},
        "warmup_history": rule, "execution_form": SPECS[name]["execution_form"],
        "state_initialization": {"schema": "state-initialization/1", "initial_state_address": None},
        "state_reset_policy": {"schema": "state-reset-policy/2", "reasons": reset_reasons},
        "bar_policy": "COMPLETED_ONLY", "missing_data_policy": "PROPAGATE",
        "numeric_validity_policy": "EXPLICIT_VALIDITY", "causal_declaration": "COMPLETED_EVENT_PREFIX",
        "evaluation_triggers": ["completed_bar"], "streaming_support": True, "batch_support": True,
        "mode_eligibility": {"research": True, "paper": False, "live": False},
        "provider_requirements": [], "resource_profile": profile,
        "reference_provenance": sorted(set(SPECS[name]["source_addresses"] +
            (hashing.content_address(node_contracts._plain(SPECS[name])),))),
        "parameter_binding": {"scheme": "analytical-contract-binding/1", **rule,
                              "parameter_names": sorted(SPECS[name]["parameters"]), "input_ports": sorted(port_fields)},
    })


def _binding_registration(name):
    return registry.registered_contract_binding(
        component=component_key(name), source_contract=source_contract(name), implementation=_binding_rule(name),
        dependency_boundary=registry.DependencyBoundary("defining_module", (contracts.binding_result,)),
    )


def _check_bound(name, parameters, bound):
    if not isinstance(bound, contracts.ResolvedNodeContract):
        raise node_contracts.NodeContractRefusal("SESSION_DATA_VERIFIED_BINDING_REQUIRED")
    replay = contracts.materialize_node_contract(source_contract(name), _binding_registration(name), parameters,
                                                 bound.document["input_binding"])
    if replay.bound_contract_address != bound.bound_contract_address:
        raise node_contracts.NodeContractRefusal("SESSION_DATA_BINDING_REPLAY_MISMATCH")
    key = component_key(name)
    document = bound.document
    if (dict(document["component"]) != {"component_id": key[0], "component_version": 2}
            or hashing.content_address(dict(document["parameters"])) != hashing.content_address(dict(parameters))
            or dict(document["resolved_contract"]["output_warmup"]) != {port: 0 for port in SPECS[name]["outputs"]}):
        raise node_contracts.NodeContractRefusal("SESSION_DATA_BINDING_MISMATCH")
    ports = document["input_binding"]["ports"]
    expected_ports = fields_by_port(name, parameters)
    if set(ports) != set(expected_ports):
        raise node_contracts.NodeContractRefusal("SESSION_DATA_INPUT_ROLES")
    primary_port = source_contract(name)["required_resolution"]["port"]
    for port, fields in expected_ports.items():
        fact = ports[port]["binding"]
        expected_role = "primary" if port == primary_port else port
        if (fact["instrument"]["role"] != expected_role or not set(fields) <= set(fact["fields"])
                or dict(fact["alignment"]) != {"kind": "EXACT", "maximum_skew_seconds": 0}
                or port == "session" and (fact["session"] != "INSTRUMENT_CALENDAR" or fact["derived_local"] is not True)):
            raise node_contracts.NodeContractRefusal("SESSION_DATA_CANONICAL_BINDING_REQUIRED")


def _precision_context():
    return _decimal.Context(prec=1536, rounding=decimal.ROUND_HALF_EVEN, Emin=-999999, Emax=999999,
                            flags=[], traps=[decimal.InvalidOperation, decimal.DivisionByZero, decimal.Overflow])


def _d(value):
    return decimal.Decimal.from_float(float(value))


def _invalid_outputs(name, cell):
    return {port: cell for port in SPECS[name]["outputs"]}


def _not_ready(name):
    return _invalid_outputs(name, validity.invalid(validity.ValidityState.INSUFFICIENT_HISTORY))


def _context_cell(inputs, field):
    if field not in inputs:
        raise node_contracts.NodeContractRefusal(f"required input {field!r} is missing")
    value = inputs[field]
    if value is None:
        return None, validity.invalid(validity.ValidityState.MISSING)
    try:
        if field == "session_id":
            if (not isinstance(value, str) or not value or len(value) > 128 or "\x00" in value
                    or unicodedata.normalize("NFC", value) != value):
                raise ValueError("canonical session id required")
            return value, None
        return _canonical_timestamp(value), None
    except (ValueError, node_contracts.NodeContractRefusal):
        return None, validity.invalid(validity.ValidityState.INVALID)


class SessionDataState:
    """Bounded typed state for unpublished canonical session/data candidates."""

    def __init__(self, name, parameters, bound_contract):
        self.name = name
        self.parameters = parameters_for(name, parameters)
        _check_bound(name, self.parameters, bound_contract)
        self.bound_contract = bound_contract
        primary_port = source_contract(name)["required_resolution"]["port"]
        fact = bound_contract.document["input_binding"]["ports"][primary_port]["binding"]
        self.timeframe = fact["timeframe"]
        self._last_time = None
        self._clear()

    def _clear(self):
        self._session_id = None
        self._session_open = None
        self._session_close = None
        self._session_count = 0
        self._current = {}
        self._prior = None
        self._range_high = None
        self._range_low = None
        self._range_complete = False
        self._anchor_started = False
        self._anchor_count = 0
        self._anchor_pv = decimal.Decimal(0)
        self._anchor_volume = decimal.Decimal(0)

    def _session_context(self, row, event_time, *, require_prefix):
        session_id = row["session_id"]
        session_open = row.get("session_open_at")
        session_close = row.get("session_close_at")
        supplied_open = session_open is not None
        if session_open is None:
            session_open = (event_time - pd.Timedelta(seconds=self.timeframe)
                            if session_id != self._session_id else self._session_open)
        if session_close is not None and session_close <= session_open:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_SESSION_INTERVAL")
        delta = (event_time - session_open).total_seconds()
        if delta <= 0 or delta % self.timeframe:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_SESSION_SLOT_ALIGNMENT")
        if session_close is not None and event_time > session_close:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_OUTSIDE_SESSION")
        new_session = session_id != self._session_id
        if new_session:
            complete = (self._session_id is not None and self._session_close is not None
                        and self._last_time == self._session_close and self._session_count > 0)
            self._prior = dict(self._current) if complete else None
            self._session_id, self._session_open, self._session_close = session_id, session_open, session_close
            self._session_count, self._current = 0, {}
            self._range_high = self._range_low = None
            self._range_complete = False
            if require_prefix and supplied_open and event_time != session_open + pd.Timedelta(seconds=self.timeframe):
                raise node_contracts.NodeContractRefusal("SESSION_DATA_INCOMPLETE_SESSION_PREFIX")
        else:
            if supplied_open and session_open != self._session_open or session_close != self._session_close:
                raise node_contracts.NodeContractRefusal("SESSION_DATA_SESSION_IDENTITY_CHANGED")
            if require_prefix and event_time != self._last_time + pd.Timedelta(seconds=self.timeframe):
                raise node_contracts.NodeContractRefusal("SESSION_DATA_MISSING_SESSION_SLOT")
        if self._session_count >= 100000:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_SESSION_PREFIX_LIMIT")
        return new_session

    def _update_aggregate(self, row):
        if "open" in row and "open" not in self._current:
            self._current["open"] = row["open"]
        if "high" in row:
            self._current["high"] = row["high"] if "high" not in self._current else max(self._current["high"], row["high"])
        if "low" in row:
            self._current["low"] = row["low"] if "low" not in self._current else min(self._current["low"], row["low"])
        if "close" in row:
            self._current["close"] = row["close"]
        if "volume" in row:
            self._current["volume"] = self._current.get("volume", decimal.Decimal(0)) + row["volume"]

    def _advance(self, row, event_time):
        name = self.name
        if name in {"OPEN", "HIGH", "LOW", "CLOSE"}:
            return {"value": row[name.lower()]}
        if name == "OHLCV":
            return {field: row[field] for field in ("open", "high", "low", "close", "volume")}
        if name == "TIME_TO_SESSION_CLOSE":
            self._session_context(row, event_time, require_prefix=False)
            if self._session_close is None or event_time > self._session_close:
                return _not_ready(name)
            return {"value": decimal.Decimal(str((self._session_close - event_time).total_seconds())) / 60}
        if name == "ANCHORED_VWAP":
            anchor = _canonical_timestamp(self.parameters["anchor_at"], parameter=True)
            if event_time < anchor:
                return _not_ready(name)
            if not self._anchor_started:
                if event_time != anchor:
                    raise node_contracts.NodeContractRefusal("SESSION_DATA_ANCHOR_HISTORY_INCOMPLETE")
                self._anchor_started = True
            if self._anchor_count >= 100000:
                raise node_contracts.NodeContractRefusal("SESSION_DATA_ANCHOR_HISTORY_LIMIT")
            self._anchor_count += 1
            typical = (row["high"] + row["low"] + row["close"]) / 3
            self._anchor_pv += typical * row["volume"]
            self._anchor_volume += row["volume"]
            return ({"value": self._anchor_pv / self._anchor_volume}
                    if self._anchor_volume > 0 else _not_ready(name))

        self._session_context(row, event_time, require_prefix=True)
        bar_index = self._session_count
        self._update_aggregate(row)
        self._session_count += 1
        if name == "BARS_SINCE_SESSION_OPEN":
            return {"value": decimal.Decimal(bar_index)}
        if name == "SESSION_OPEN":
            return {"value": self._current["open"]}
        if name == "SESSION_HIGH":
            return {"value": self._current["high"]}
        if name == "SESSION_LOW":
            return {"value": self._current["low"]}
        if name == "SESSION_OPEN_HIGH_LOW":
            return {key: self._current[key] for key in ("open", "high", "low")}
        if name == "DISTANCE_FROM_SESSION_HIGH_LOW":
            return {"from_high": self._current["high"] - row["close"],
                    "from_low": row["close"] - self._current["low"]}
        if name == "VWAP":
            typical = (row["high"] + row["low"] + row["close"]) / 3
            self._current["vwap_pv"] = self._current.get("vwap_pv", decimal.Decimal(0)) + typical * row["volume"]
            self._current["vwap_volume"] = self._current.get("vwap_volume", decimal.Decimal(0)) + row["volume"]
            return ({"value": self._current["vwap_pv"] / self._current["vwap_volume"]}
                    if self._current["vwap_volume"] > 0 else _not_ready(name))
        if name == "OPENING_RANGE":
            deadline = self._session_open + pd.Timedelta(minutes=self.parameters["range_minutes"])
            if self._session_close is not None and deadline > self._session_close:
                raise node_contracts.NodeContractRefusal("SESSION_DATA_OPENING_RANGE_OUTSIDE_SESSION")
            if not self._range_complete:
                if event_time <= deadline:
                    self._range_high = row["high"] if self._range_high is None else max(self._range_high, row["high"])
                    self._range_low = row["low"] if self._range_low is None else min(self._range_low, row["low"])
                if event_time >= deadline:
                    self._range_complete = True
            if not self._range_complete:
                return _not_ready(name)
            return {"high": self._range_high, "low": self._range_low,
                    "middle": (self._range_high + self._range_low) / 2}
        if name in {"PREVIOUS_SESSION_FIELDS", "PREVIOUS_SESSION_OHLC"}:
            if self._prior is None:
                return _not_ready(name)
            if name == "PREVIOUS_SESSION_FIELDS":
                return {"value": self._prior[self.parameters["field"]]}
            return {key: self._prior[key] for key in ("open", "high", "low", "close")}
        raise node_contracts.NodeContractRefusal("SESSION_DATA_IMPLEMENTATION_UNAVAILABLE")

    def step(self, inputs, *, event_time, reset_reasons=(), event_kind="completed_bar"):
        if event_kind != "completed_bar":
            raise node_contracts.NodeContractRefusal("SESSION_DATA_COMPLETED_BAR_REQUIRED")
        timestamp = _canonical_timestamp(event_time)
        if self._last_time is not None and timestamp <= self._last_time:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_EVENT_ORDER")
        reasons = common.contract_reset_reasons(self.bound_contract, reset_reasons)
        expected_ports = fields_by_port(self.name, self.parameters)
        if (not isinstance(inputs, abc.Mapping) or set(inputs) != set(expected_ports)
                or any(not isinstance(inputs[port], abc.Mapping) for port in expected_ports)):
            raise node_contracts.NodeContractRefusal("SESSION_DATA_NAMED_INPUT_PORTS")
        parsed, invalids = {}, []
        for port, declared in expected_ports.items():
          for field in (item.lower() for item in declared):
            if field in NUMERIC_FIELDS:
                cell = common.required_numeric_scalar(inputs[port], field)
                invalids.append(cell)
                if cell.state is validity.ValidityState.VALID:
                    parsed[field] = _d(cell.value)
            else:
                value, bad = _context_cell(inputs[port], field)
                if bad is not None:
                    invalids.append(bad)
                else:
                    parsed[field] = value
        bad = validity.propagate(invalids)
        if bad is None and "volume" in parsed and parsed["volume"] < 0:
            bad = validity.invalid(validity.ValidityState.INVALID)
        if bad is None and "high" in parsed and "low" in parsed:
            if parsed["high"] < parsed["low"] or any(field in parsed and not parsed["low"] <= parsed[field] <= parsed["high"] for field in ("open", "close")):
                bad = validity.invalid(validity.ValidityState.INVALID)
        if reasons or bad is not None:
            self._clear()
        if bad is not None:
            self._last_time = timestamp
            return _invalid_outputs(self.name, bad)
        with decimal.localcontext(_precision_context()):
            produced = self._advance(parsed, timestamp)
        self._last_time = timestamp
        if set(produced) != set(SPECS[self.name]["outputs"]):
            raise node_contracts.NodeContractRefusal("SESSION_DATA_OUTPUT_CLOSURE")
        result = {}
        for port, value in produced.items():
            if isinstance(value, validity.NumericValue):
                result[port] = value
                continue
            number = float(value)
            result[port] = (validity.valid(number) if math.isfinite(number)
                            else validity.invalid(validity.ValidityState.MATHEMATICALLY_UNDEFINED))
        return result

    def snapshot(self):
        def encode_map(values):
            return {key: str(value) for key, value in sorted(values.items())}
        body = {
            "schema": "analytical-session-data-state/2", "component": list(component_key(self.name)),
            "bound_contract_address": self.bound_contract.bound_contract_address,
            "parameters": node_contracts._plain(self.parameters), "timeframe": self.timeframe,
            "last_time": self._last_time.isoformat() if self._last_time is not None else None,
            "session_id": self._session_id,
            "session_open": self._session_open.isoformat() if self._session_open is not None else None,
            "session_close": self._session_close.isoformat() if self._session_close is not None else None,
            "session_count": self._session_count, "current": encode_map(self._current),
            "prior": None if self._prior is None else encode_map(self._prior),
            "range_high": None if self._range_high is None else str(self._range_high),
            "range_low": None if self._range_low is None else str(self._range_low),
            "range_complete": self._range_complete, "anchor_started": self._anchor_started,
            "anchor_count": self._anchor_count, "anchor_pv": str(self._anchor_pv),
            "anchor_volume": str(self._anchor_volume),
        }
        return {**body, "payload_address": hashing.content_address(body)}

    @classmethod
    def restore(cls, name, parameters, bound_contract, document):
        state = cls(name, parameters, bound_contract)
        fields = {"schema", "component", "bound_contract_address", "parameters", "timeframe", "last_time",
                  "session_id", "session_open", "session_close", "session_count", "current", "prior",
                  "range_high", "range_low", "range_complete", "anchor_started", "anchor_count",
                  "anchor_pv", "anchor_volume", "payload_address"}
        if not isinstance(document, abc.Mapping) or set(document) != fields:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_CLOSED_SCHEMA")
        body = {key: value for key, value in document.items() if key != "payload_address"}
        if (document["schema"] != "analytical-session-data-state/2"
                or document["component"] != list(component_key(name))
                or document["bound_contract_address"] != bound_contract.bound_contract_address
                or hashing.content_address(document["parameters"]) != hashing.content_address(dict(state.parameters))
                or document["timeframe"] != state.timeframe
                or hashing.content_address(body) != document["payload_address"]):
            raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_IDENTITY")
        if type(document["session_count"]) is not int or not 0 <= document["session_count"] <= 100000:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_COUNTER")
        if type(document["anchor_count"]) is not int or not 0 <= document["anchor_count"] <= 100000:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_COUNTER")
        if type(document["range_complete"]) is not bool or type(document["anchor_started"]) is not bool:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_BOOLEAN")
        def decode(value):
            if not isinstance(value, str) or len(value) > 1560:
                raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_DECIMAL")
            try:
                result = decimal.Decimal(value)
                if not result.is_finite() or str(result) != value or result.copy_abs() > decimal.Decimal("1e313"):
                    raise ValueError("bounded canonical decimal required")
                return result
            except (decimal.DecimalException, ValueError) as exc:
                raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_DECIMAL") from exc
        def decode_map(value):
            if not isinstance(value, abc.Mapping) or set(value) - {"open", "high", "low", "close", "volume", "vwap_pv", "vwap_volume"}:
                raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_AGGREGATE")
            return {key: decode(item) for key, item in value.items()}
        state._last_time = _canonical_timestamp(document["last_time"]) if document["last_time"] is not None else None
        state._session_id = document["session_id"]
        if state._session_id is not None and (not isinstance(state._session_id, str) or not state._session_id or len(state._session_id) > 128):
            raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_SESSION")
        state._session_open = _canonical_timestamp(document["session_open"]) if document["session_open"] is not None else None
        state._session_close = _canonical_timestamp(document["session_close"]) if document["session_close"] is not None else None
        state._session_count = document["session_count"]
        state._current = decode_map(document["current"])
        state._prior = None if document["prior"] is None else decode_map(document["prior"])
        state._range_high = None if document["range_high"] is None else decode(document["range_high"])
        state._range_low = None if document["range_low"] is None else decode(document["range_low"])
        state._range_complete = document["range_complete"]
        state._anchor_started, state._anchor_count = document["anchor_started"], document["anchor_count"]
        state._anchor_pv, state._anchor_volume = decode(document["anchor_pv"]), decode(document["anchor_volume"])
        if (state._session_count > 0 and state._session_id is None
                or state._session_count == 0 and state._session_id is not None and name != "TIME_TO_SESSION_CLOSE"):
            raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_SESSION")
        if state._anchor_volume < 0:
            raise node_contracts.NodeContractRefusal("SESSION_DATA_STATE_VOLUME")
        return state


def evaluate(name, parameters, inputs, *, bound_contract, resets=None):
    state = SessionDataState(name, parameters, bound_contract)
    required = fields_by_port(name, parameters)
    if (not isinstance(inputs, abc.Mapping) or set(inputs) != set(required)
            or any(not isinstance(inputs[port], abc.Mapping) for port in required)):
        raise node_contracts.NodeContractRefusal("SESSION_DATA_NAMED_INPUT_PORTS")
    index, columns = None, {}
    for port, fields in required.items():
      columns[port] = {}
      for field in fields:
        key = field.lower(); series = inputs[port].get(key)
        if not isinstance(series, pd.Series):
            raise node_contracts.NodeContractRefusal("SESSION_DATA_INDEXED_FIELD_REQUIRED")
        if (not isinstance(series.index, pd.DatetimeIndex) or series.index.tz is None or series.index.hasnans
                or not series.index.is_unique or not series.index.is_monotonic_increasing):
            raise node_contracts.NodeContractRefusal("SESSION_DATA_CANONICAL_INDEX_REQUIRED")
        if index is None:
            index = series.index
        if not series.index.equals(index):
            raise node_contracts.NodeContractRefusal("SESSION_DATA_EXACT_ALIGNMENT_REQUIRED")
        columns[port][key] = series.tolist()
    resets = ((),) * len(index) if resets is None else resets
    if not isinstance(resets, (tuple, list)) or len(resets) != len(index):
        raise node_contracts.NodeContractRefusal("SESSION_DATA_RESET_ARRAY_REQUIRED")
    results = {port: [] for port in sorted(SPECS[name]["outputs"])}
    for i, event_time in enumerate(index):
        produced = state.step({port: {key: values[i] for key, values in values_by_field.items()}
                               for port, values_by_field in columns.items()},
                              event_time=event_time, reset_reasons=resets[i])
        for port, value in produced.items():
            results[port].append(value)
    return {port: pd.Series(values, index=index, name=port, dtype=object) for port, values in results.items()}


def implementation_for(name):
    def implementation(parameters, inputs, *, evaluation_context=None, _name=name):
        if (not isinstance(evaluation_context, abc.Mapping) or "bound_contract" not in evaluation_context
                or set(evaluation_context) - {"bound_contract", "resets"}):
            raise node_contracts.NodeContractRefusal("SESSION_DATA_VERIFIED_EVALUATION_CONTEXT_REQUIRED")
        return evaluate(_name, parameters, inputs, bound_contract=evaluation_context["bound_contract"],
                        resets=evaluation_context.get("resets"))
    return implementation


V2_TYPES = node_contracts._freeze({
    ("analytical.market_frame", 2): {"type_id": "analytical.market_frame", "type_version": 2,
        "shapes": ["series"], "runtime_representation": "named indexed canonical fields and session context"},
    ("analytical.float64", 2): {"type_id": "analytical.float64", "type_version": 2,
        "shapes": ["series"], "runtime_representation": "indexed NumericValue float64 cells"},
})
V2_COMPONENTS = node_contracts._freeze({component_key(name): descriptor(name) for name in NAMES})
NODE_CONTRACTS = node_contracts._freeze({component_key(name): source_contract(name) for name in NAMES})
DATA_REQUIREMENTS = node_contracts._freeze({})
CONTRACT_BINDINGS = node_contracts._freeze({component_key(name): _binding_registration(name) for name in NAMES})
V2_IMPLEMENTATIONS = node_contracts._freeze({component_key(name): registry.registered_v2_implementation(
    component=component_key(name), implementation=implementation_for(name),
    dependency_boundary=registry.DependencyBoundary(
        "defining_module", (abc, pd, math, decimal, _decimal, unicodedata, hashing,
                            node_contracts, registry, validity, common, contracts)),
) for name in NAMES})
