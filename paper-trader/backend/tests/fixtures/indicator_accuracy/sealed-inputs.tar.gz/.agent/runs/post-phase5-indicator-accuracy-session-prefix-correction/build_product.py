from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import pprint


ROOT = Path(__file__).resolve().parents[3]
RUN = ROOT / ".agent/runs/post-phase5-indicator-accuracy-session-prefix-correction"
ORIGINAL_RUN = ROOT / ".agent/runs/post-phase5-indicator-accuracy-session-data"
TARGET = ROOT / "paper-trader/backend/app/ir/first_party/analytical_v2/session_data.py"
CAPSULE = ROOT / "paper-trader/docs/agent/tasks/post-phase5-indicator-accuracy-session-prefix-correction.md"
ORIGINAL_CAPSULE = ROOT / "paper-trader/docs/agent/tasks/post-phase5-indicator-accuracy-session-data.md"
MATRIX = ROOT / ".agent/runs/post-phase5-indicator-accuracy-correction-replan/component-matrix.json"
AUTHORITY = ROOT / ".agent/runs/post-phase5-indicator-accuracy-correction-replan/source-authority.json"
SPECIFICATION = ROOT / ".agent/runs/post-phase5-indicator-accuracy-correction-replan/specification.py"
ORIGINAL_BODY = ORIGINAL_RUN / "session_data_body.py"
RECEIPT = RUN / "source-receipt.json"

AFFECTED = (
    "DISTANCE_FROM_SESSION_HIGH_LOW",
    "PREVIOUS_SESSION_FIELDS",
    "PREVIOUS_SESSION_OHLC",
    "SESSION_HIGH",
    "SESSION_LOW",
    "SESSION_OPEN",
    "SESSION_OPEN_HIGH_LOW",
    "VWAP",
)

SEALED_INPUT_HASHES = {
    ".agent/runs/post-phase5-indicator-accuracy-session-data/build_product.py":
        "c865f8d58a9e2e4404d75a8d6bd94e35995e51f170a31378074a2f71f4952321",
    ".agent/runs/post-phase5-indicator-accuracy-session-data/session_data_body.py":
        "8fc337d04e5992b2d080864a153e2c7c5839bf3308d67131be44d47a1d73a56a",
    ".agent/runs/post-phase5-indicator-accuracy-correction-replan/specification.py":
        "09ec1f15fd915a6f6ae14af24b77532224cbf28c15456734a775d95c9637cdcb",
    ".agent/runs/post-phase5-indicator-accuracy-correction-replan/component-matrix.json":
        "95050aec6ab623e9f0fb606a0f5547f90dce93fc20a9d9944c128152c1394959",
}


def _front_matter(path: Path) -> dict:
    return json.loads(path.read_text().split("---", 2)[1])


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _load_specification():
    spec = importlib.util.spec_from_file_location(
        "session_data_prefix_correction_specification", SPECIFICATION,
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def _corrected_body() -> str:
    body = ORIGINAL_BODY.read_text()
    old = '''        if new_session:
            complete = (self._session_id is not None and self._session_close is not None
                        and self._last_time == self._session_close and self._session_count > 0)
            self._prior = dict(self._current) if complete else None
            self._session_id, self._session_open, self._session_close = session_id, session_open, session_close
            self._session_count, self._current = 0, {}
            self._range_high = self._range_low = None
            self._range_complete = False
            if require_prefix and supplied_open and event_time != session_open + pd.Timedelta(seconds=self.timeframe):
                raise node_contracts.NodeContractRefusal("SESSION_DATA_INCOMPLETE_SESSION_PREFIX")
'''
    new = '''        if new_session:
            if require_prefix and supplied_open and event_time != session_open + pd.Timedelta(seconds=self.timeframe):
                raise node_contracts.NodeContractRefusal("SESSION_DATA_INCOMPLETE_SESSION_PREFIX")
            expected_count = (None if self._session_close is None or self._session_open is None else
                              int((self._session_close - self._session_open).total_seconds() // self.timeframe))
            complete = (self._session_id is not None and self._session_close is not None
                        and self._last_time == self._session_close
                        and self._session_count == expected_count)
            self._prior = dict(self._current) if complete else None
            self._session_id, self._session_open, self._session_close = session_id, session_open, session_close
            self._session_count, self._current = 0, {}
            self._range_high = self._range_low = None
            self._range_complete = False
'''
    if body.count(old) != 1:
        raise RuntimeError("sealed body no longer contains the exact F01 guard block")
    body = body.replace(old, new)
    old_invalid = '''        if reasons or bad is not None:
            self._clear()
        if bad is not None:
            self._last_time = timestamp
            return _invalid_outputs(self.name, bad)
'''
    new_invalid = '''        if reasons or bad is not None:
            self._clear()
        if bad is not None:
            if (self.name in SESSION_PREFIX_NAMES
                    and {"session_id", "session_open_at"} <= set(parsed)):
                self._session_id = parsed["session_id"]
                self._session_open = parsed["session_open_at"]
                self._session_close = parsed.get("session_close_at")
            self._last_time = timestamp
            return _invalid_outputs(self.name, bad)
'''
    if body.count(old_invalid) != 1:
        raise RuntimeError("sealed body no longer contains the exact invalid-reset block")
    return body.replace(old_invalid, new_invalid)


def main() -> None:
    for relative, expected in SEALED_INPUT_HASHES.items():
        actual = _sha(ROOT / relative)
        if actual != expected:
            raise RuntimeError(f"sealed input changed: {relative}: {actual}")

    correction = _front_matter(CAPSULE)
    original = _front_matter(ORIGINAL_CAPSULE)
    affected = tuple(sorted(correction["affected_components"]))
    if affected != AFFECTED:
        raise RuntimeError("correction capsule affected-component set changed")

    scope = tuple(original["component_scope"])
    rows = {row["name"]: row for row in json.loads(MATRIX.read_text())["records"]}
    records = json.loads(AUTHORITY.read_text())["records"]
    specification = _load_specification()
    product_specs = {}
    for name in scope:
        row = rows[name]
        target = dict(specification.SPECS[name])
        target["decision"] = row["decision"]
        target["threshold_class"] = row["threshold_class"]
        target["source_addresses"] = tuple(
            "sha256:" + records[source]["sha256"] for source in row["source_authorities"]
        )
        if name in AFFECTED:
            if "session_open_at" in target["inputs"]:
                raise RuntimeError(f"sealed specification already declares session_open_at: {name}")
            target["inputs"] = sorted((*target["inputs"], "session_open_at"))
        product_specs[name] = target

    header = '''"""Unpublished session/data v2 candidates and immutable refusal facts.

Generated by the sealed F01-FRESH session-prefix correction producer from the
accepted specification and body. Exactly eight candidates add canonical
SESSION_OPEN_AT. This module remains unpublished and grants no provider, calendar,
paper/live or deployment authority.
"""
from __future__ import annotations

import collections.abc as abc
import decimal
import _decimal
import math
import unicodedata
import pandas as pd

from app.ir import hashing, node_contracts, registry, validity
from app.ir.first_party.analytical_v2 import common, contracts

# BEGIN immutable accepted matrix facts plus F01-FRESH input correction; regenerate, do not hand-edit.
SPECS = node_contracts._freeze('''
    footer = ''')
# END immutable accepted matrix facts plus F01-FRESH input correction.
'''
    output = (
        header
        + pprint.pformat(product_specs, width=112, sort_dicts=True)
        + footer
        + _corrected_body()
    )
    TARGET.write_text(output)
    receipt = {
        "schema": "session-prefix-correction-source-receipt/1",
        "decision": "F01-FRESH",
        "affected_components": list(AFFECTED),
        "sealed_input_hashes": SEALED_INPUT_HASHES,
        "product_path": str(TARGET.relative_to(ROOT)),
        "product_sha256": _sha(TARGET),
        "component_count": len(scope),
        "candidate_count": sum(rows[name]["decision"] == "REPLACE_V2" for name in scope),
        "refusal_count": sum(rows[name]["decision"] == "REFUSE" for name in scope),
        "original_specification_and_body_edited": False,
    }
    RECEIPT.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps(receipt, sort_keys=True))


if __name__ == "__main__":
    main()
