# Source, licence and oracle access policy

## Inspected sources

| Source | Exact version | Observed terms and decision |
|---|---|---|
| [TA-Lib core licence](https://github.com/TA-Lib/ta-lib/blob/2247d599bddf37ed37e3a709371517e46efc66f6/LICENSE) | v0.7.1, commit `2247d599bddf37ed37e3a709371517e46efc66f6` | BSD-3-Clause text inspected at that commit. REFERENCE ONLY; no product or test dependency adoption in this replan. Captured function sources, utility/global settings and upstream tests are hashed in `sources/manifest.json`. |
| [TA-Lib wrapper licence](https://github.com/TA-Lib/ta-lib-python/blob/a9ff1b47b3ddbd57274116645d688c0ed677338b/LICENSE) | v0.7.1, commit `a9ff1b47b3ddbd57274116645d688c0ed677338b` | BSD-2-Clause text inspected separately. REFERENCE ONLY. A wrapper version is not a native core/compiler/build identity. |
| [NIST scale](https://www.itl.nist.gov/div898/handbook/eda/section3/eda356.htm), [least squares](https://www.itl.nist.gov/div898/handbook/pmd/section1/pmd141.htm) | Captured exact content hashes for scale and least-squares sections | Public mathematical documentation, REFERENCE ONLY; no page-text redistribution or legal-clearance claim. The product's explicit ddof/unit/undefined variants are recorded rather than attributed silently to NIST. |
| [NumPy percentile documentation](https://numpy.org/doc/2.3/reference/generated/numpy.percentile.html) | Manual version 2.3 plus captured content hash | Official method/parameter documentation, REFERENCE ONLY. No numpy install/upgrade; current product lock remains numpy 2.5.2. |
| [Rogers–Satchell paper](https://www.skokholm.co.uk/wp-content/uploads/2016/01/R_Satchell_HLOC.pdf) | 1991 paper, captured PDF hash | Copyrighted primary research, read-only internal reference. No paper redistribution or code adoption. |
| [Yang–Zhang paper](https://www.atmif.com/papers/range.pdf) | Journal of Business 73(3), 2000, equations 2–10, captured PDF hash | Copyrighted primary research, read-only internal reference. The window-dependent Yang–Zhang weighting is inspected; its different GK benchmark is not adopted as the existing indicator. |
| Strategy OS specification | Exact `specification.py`, canonical market-data/rulebook and architecture hashes | Authored mathematical/domain definitions, explicitly not external vendor parity or completed independent oracle evidence. |
| TradingView | No access granted | EXCLUDED: no private library, hosted probe, export, scraping, credentials or unofficial API. The predecessor access refusal is retained; nothing here circumvents it. |

Source hashes bind what was inspected. They are not legal compatibility decisions,
proven numerical correctness, or trusted software provenance attestations. Any
licence-sensitive copying/adoption must stop for the owner/legal gate. Public
sources were read without credentials; no provider network was contacted.

## Reference environment gate

No oracle package was installed and no external indicator implementation was
executed in this replan. Future numerical assurance must record exact native core,
wrapper, compiler/platform, package hashes and product lock identities. Set TA-Lib
compatibility to DEFAULT and unstable periods to zero; use complete valid segments
and separately test the specified missing/invalid policies.

`post-phase5-indicator-accuracy-contract-assurance` owns the reference-environment
receipt before the first TA-Lib-backed numerical assurance. If no already approved
exact executor exists, it must obtain explicit owner approval for a disposable,
reference-only TA-Lib 0.7.1 environment before provisioning it. This is not permission
to add TA-Lib to backend requirements or alter pandas/numpy locks. Without that
approval/evidence, the affected TA-Lib parity gate remains blocked; a copied product
formula or a stale output file cannot substitute for it. Independently authored
scalar/specification vectors remain a separate required proof.

The prior audit used pandas 2.3.2, whereas the current locked/exported environment
is pandas 3.0.5 / numpy 2.5.2. Preserve the old verdict as historical evidence and
rerun future correctness/compatibility claims in the locked product environment.
This difference is not permission for an unreviewed dependency upgrade/downgrade.

## Deferred numerical conventions

Supertrend, Ichimoku and Garman–Klass remain explicitly unavailable. The non-executable
`post-phase5-indicator-accuracy-deferred-source-replan` owns any later attempt to
retrieve authoritative conventions, settle seeds/displacement and define independent
vectors. It requires a new owner authorization. A later source decision cannot
silently enable a record or mutate an already accepted version.
