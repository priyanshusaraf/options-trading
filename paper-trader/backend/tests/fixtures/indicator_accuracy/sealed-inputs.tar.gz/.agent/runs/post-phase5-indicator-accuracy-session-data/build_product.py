from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import pprint


ROOT = Path(__file__).resolve().parents[3]
RUN = ROOT / ".agent/runs/post-phase5-indicator-accuracy-session-data"
TARGET = ROOT / "paper-trader/backend/app/ir/first_party/analytical_v2/session_data.py"
CAPSULE = ROOT / "paper-trader/docs/agent/tasks/post-phase5-indicator-accuracy-session-data.md"
MATRIX = ROOT / ".agent/runs/post-phase5-indicator-accuracy-correction-replan/component-matrix.json"
AUTHORITY = ROOT / ".agent/runs/post-phase5-indicator-accuracy-correction-replan/source-authority.json"
SPECIFICATION = ROOT / ".agent/runs/post-phase5-indicator-accuracy-correction-replan/specification.py"


def main() -> None:
    capsule = json.loads(CAPSULE.read_text().split("---", 2)[1])
    scope = tuple(capsule["component_scope"])
    rows = {row["name"]: row for row in json.loads(MATRIX.read_text())["records"]}
    records = json.loads(AUTHORITY.read_text())["records"]
    spec = importlib.util.spec_from_file_location("session_data_specification", SPECIFICATION)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    product_specs = {}
    for name in scope:
        row = rows[name]
        target = dict(module.SPECS[name])
        target["decision"] = row["decision"]
        target["threshold_class"] = row["threshold_class"]
        target["source_addresses"] = tuple("sha256:" + records[source]["sha256"]
                                           for source in row["source_authorities"])
        product_specs[name] = target
    header = '''"""Unpublished session/data v2 candidates and immutable refusal facts.

Generated from the sealed 125-component matrix. This module is not composed into
the registry and grants no provider, calendar, paper/live or deployment authority.
"""
from __future__ import annotations

import collections.abc as abc
import decimal
import _decimal
import math
import unicodedata
import pandas as pd

from app.ir import hashing, node_contracts, registry, validity
from app.ir.first_party.analytical_v2 import common, contracts

# BEGIN immutable accepted matrix facts; regenerate, do not hand-edit.
SPECS = node_contracts._freeze('''
    footer = ''')
# END immutable accepted matrix facts.
'''
    body = (RUN / "session_data_body.py").read_text()
    TARGET.write_text(header + pprint.pformat(product_specs, width=112, sort_dicts=True) + footer + body)
    print(json.dumps({"components": len(scope),
                      "candidates": sum(row["decision"] == "REPLACE_V2" for row in (rows[name] for name in scope)),
                      "refusals": sum(row["decision"] == "REFUSE" for row in (rows[name] for name in scope)),
                      "target": str(TARGET.relative_to(ROOT))}))


if __name__ == "__main__":
    main()
